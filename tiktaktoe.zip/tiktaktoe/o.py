import tkinter as tk
import tkinter.messagebox
import time

window = tk.Tk()
window.geometry("600x200+800+300")

c=100
num = str(c)+"%"

la = tk.Label(window, text="林詠翊的情商指數", font=("Arial", 50))
la.pack()
las = tk.Label(window, text=num, font=("Arial", 50))
las.pack()

def count():
    global c
    c-=10
    if c>0:
        new_num=str(c)+"%"
        las.config(text=new_num)
        window.after(500,count)
    elif c==0:
        new_num=str(c)+"%"
        las.config(text=new_num)
        tk.messagebox.showwarning(message="沒救了！")


window.after(2000,count)

window.mainloop()