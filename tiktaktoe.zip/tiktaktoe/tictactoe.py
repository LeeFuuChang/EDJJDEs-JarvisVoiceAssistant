from selenium import webdriver
import tkinter.messagebox
import debugWeb as db
import tkinter as tk
import time

db.WebCreate()

debug = webdriver.Chrome(r"C:\Users\a0988\OneDrive\Desktop\tiktaktoe\chromedriver.exe")
debug.get(r"C:\Users\a0988\OneDrive\Desktop\tiktaktoe\SituationChecking.html")

window = tk.Tk()
window.title("TicTacToe")
window.geometry("400x500+500+100")
window.configure(background='black')
db.Output(" --Window Created")
debug.refresh()

Title = tk.Label(window, text="TicTacToe", font=("Arial", 30), bg="black", fg="white")
Title.pack(pady=25, side=tk.TOP)
YourTurn = tk.Button(window, text="Guest's Turn", font=("Arial", 10), bg="white", fg="black")
YourTurn.place(x=300, y=35, width=90, height=35)
CompTurn = tk.Button(window, text="ComAI's Turn", font=("Arial", 10), bg="black", fg="black")
CompTurn.place(x=10, y=35, width=90, height=35)

box = 9
rd = 0
ii = 0
Blist = [""]*9
button = [
    "one", "two", "three",
    "four", "five", "six",
    "seven", "eight", "nine"]

def click(evt): #click func
    global rd, box
    B = evt.widget
    Btext=B["text"]
    Bid = int(str(B).replace(".!button", ""))-2
    print(Bid)
    box-=1
    if(rd%2 == 1 and Btext == ""):
        B.config(text="X")
        YourTurn.config(bg="white")
        CompTurn.config(bg="black")
        db.Output("AI --Clicked")
        debug.refresh()
        debug.execute_script("window.scrollTo(0, document.body.scrollHeight)")
        rd+=1
    elif(Btext == ""):
        B.config(text="O")
        YourTurn.config(bg="black")
        CompTurn.config(bg="white")
        db.Output("Player --Clicked")
        debug.refresh()
        debug.execute_script("window.scrollTo(0, document.body.scrollHeight)")
        rd+=1

    if box==0: #game end
        pass

db.Output(" --Click Defined")
debug.refresh()

for a in range(3): #gen buttons
    for b in range(3):
        placex = b*130+10
        placey = a*130+110
        button[ii] = tk.Button(window, text="", font=("Arial", 100))
        button[ii].place(x=placex, y=placey, width=120, height=120)
        button[ii].bind("<Button-1>", click)
        ii+=1

db.Output(" --Button Created")
debug.refresh()

db.Output(" --Game Started")
debug.refresh()

















window.mainloop()